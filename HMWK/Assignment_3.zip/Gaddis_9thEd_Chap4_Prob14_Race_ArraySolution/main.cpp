/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:    main.cpp
 * Author:  Noah Garthwaite
 * Created on January 13, 2024, 5:57 PM
 * Purpose: Gaddis_9thEd_Chap4_Prob14_Race
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
#include <string>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const char NUM_RUNNERS = 3;
const char OUT_WIDTH = 3;

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Set the random number seed

    //Declare Variables
    string rnrName[NUM_RUNNERS];
    short rnrTime[NUM_RUNNERS];

    //Initialize or input i.e. set variable values
    cout << "Race Ranking Program" << endl;
    cout << "Input 3 Runners" << endl;
    cout << "Their names, then their times" << endl;
    
    for (char i = 0; i < NUM_RUNNERS; i++) {
        cin >> rnrName[i] >> rnrTime[i];
        while (rnrTime[i] < 0) {
            cout << "Runner time must be a positive number." << endl;
            cin >> rnrTime[i];
        }
    }
    
    for (short i = 0; i < NUM_RUNNERS; i++) {
        short time1 = rnrTime[i];
        string name1 = rnrName[i];
        for (short j = i; j < NUM_RUNNERS; j++) {
            short time2 = rnrTime[j];
            string name2 = rnrName[j];
            if (i == j) {
                continue;
            }
            else if (time2 < time1) {
                rnrTime[i] = time2;
                rnrTime[j] = time1;
                rnrName[i] = name2;
                rnrName[j] = name1;
            }
        }
    }
    
    //Map inputs -> outputs

    //Display the outputs
    for (char i = 0; i < NUM_RUNNERS; i++) {
        cout << rnrName[i] << "\t" << setw(OUT_WIDTH) << rnrTime[i];
        if (i + 1 != NUM_RUNNERS) {
            cout << endl;
        }
    }
    //Exit stage right or left!
    return 0;
}
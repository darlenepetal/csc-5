/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Noah Garthwaite
 * Created on January 3, 2024, 8:17 PM
 * Purpose: Savitch Chapter 1 Practice Program 2 FavouriteNumber 
 */

#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    int favouriteNumber;
    cout << "Press return after entering a number.\n";
    cout << "Enter your favourite number: \n";
    cin >> favouriteNumber;
    cout << "Your favourite number is ";
    cout << favouriteNumber;
    cout << ".\n";
    return 0;
}
